ASTRA synthetic gating demo — source package (v5)

Contents:
- LaTeX manuscript sources (paper.tex, sections/, references.bib)
- Generated bibliography output (paper.bbl) included for build robustness

Build (example):
- pdflatex paper.tex
- bibtex paper
- pdflatex paper.tex
- pdflatex paper.tex
